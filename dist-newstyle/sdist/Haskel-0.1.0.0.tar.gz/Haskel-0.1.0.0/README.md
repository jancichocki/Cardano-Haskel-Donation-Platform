# Haskel

This project demonstrates a Haskell application for tracking donations, performing KYC, and more.
