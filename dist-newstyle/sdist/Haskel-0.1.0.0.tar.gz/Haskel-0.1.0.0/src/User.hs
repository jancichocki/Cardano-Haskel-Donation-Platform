{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE DeriveGeneric #-}

module User where

import Data.Text (Text)
import System.Random (randomRIO)
import GHC.Generics (Generic)
import Data.Aeson (FromJSON, ToJSON)

-- User data type
data User = User
  { userId :: Int
  , userName :: Text
  , userEmail :: Text
  , userVerified :: Bool
  , userDonations :: [Donation]
  } deriving (Show, Generic)

instance FromJSON User
instance ToJSON User

-- Function to generate a random user ID
generateUserId :: IO Int
generateUserId = randomRIO (1000, 9999)

-- Function to simulate the KYC process
performKYC :: User -> IO Bool
performKYC user = do
  putStrLn $ "Performing KYC for user: " ++ show (userName user)
  -- Simulate a KYC check (In reality, this would involve calling an external KYC service)
  return True

-- Function to register a new user
registerUser :: Text -> Text -> IO User
registerUser name email = do
  uid <- generateUserId
  let newUser = User uid name email False []
  putStrLn $ "Registering user: " ++ show name
  return newUser

-- Function to verify a user
verifyUser :: User -> IO User
verifyUser user = do
  kycResult <- performKYC user
  let verifiedUser = user { userVerified = kycResult }
  if kycResult
    then putStrLn $ "User " ++ show (userName user) ++ " has been verified."
    else putStrLn $ "User " ++ show (userName user) ++ " failed KYC."
  return verifiedUser
