{-# LANGUAGE OverloadedStrings #-}

module Dashboard where

import Data.Aeson (FromJSON, ToJSON)
import Donation (Donation)
import Data.Text (Text)
import qualified Data.Text as T
import GHC.Generics (Generic)

-- Dashboard data type
data Dashboard = Dashboard
  { donations :: [Donation]
  } deriving (Show, Generic)

instance FromJSON Dashboard
instance ToJSON Dashboard

-- Function to display the dashboard
displayDashboard :: Dashboard -> IO ()
displayDashboard (Dashboard ds) = do
  putStrLn "Dashboard:"
  mapM_ print ds

-- Function to update the dashboard with a new donation
updateDashboard :: Dashboard -> Donation -> Dashboard
updateDashboard (Dashboard ds) d = Dashboard (d:ds)
