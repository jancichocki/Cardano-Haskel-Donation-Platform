{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE DeriveGeneric #-}

module Donation where

import Data.Text (Text)
import GHC.Generics (Generic)
import Data.Aeson (FromJSON, ToJSON)

-- Donation data type
data Donation = Donation
  { donationName :: Text
  , donationAmount :: Double
  } deriving (Show, Generic)

instance FromJSON Donation
instance ToJSON Donation
