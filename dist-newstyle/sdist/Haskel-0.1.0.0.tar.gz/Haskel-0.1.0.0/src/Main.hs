{-# LANGUAGE OverloadedStrings #-}

module Main where

import Data.Aeson (FromJSON, ToJSON, decodeFileStrict, encodeFile)
import Data.Text (Text)
import qualified Data.Text as T
import Data.Time.Clock (getCurrentTime)
import System.Random (randomRIO)
import User (User(..), registerUser, verifyUser)
import Dashboard (Dashboard(..), initializeDashboard, updateDashboard)

-- Function to read JSON data from a file
readJSON :: FromJSON a => FilePath -> IO (Maybe a)
readJSON = decodeFileStrict

-- Function to write JSON data to a file
writeJSON :: ToJSON a => FilePath -> a -> IO ()
writeJSON = encodeFile

main :: IO ()
main = do
  putStrLn "Enter your name:"
  name <- T.pack <$> getLine
  putStrLn "Enter your email:"
  email <- T.pack <$> getLine

  newUser <- registerUser name email
  verifiedUser <- verifyUser newUser

  putStrLn $ "User registration and verification complete: " ++ show verifiedUser

  -- Initialize or load the dashboard
  mDashboard <- readJSON "dashboard.json" :: IO (Maybe Dashboard)
  let dashboard = maybe initializeDashboard id mDashboard

  -- Update the dashboard
  let updatedDashboard = updateDashboard dashboard verifiedUser
  writeJSON "dashboard.json" updatedDashboard

  putStrLn "Dashboard updated successfully."
